#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin >> t;
    cout << t*20 << endl;
    return 0;
}