#include <bits/stdc++.h>
using namespace std;
int main(){
    unsigned long long int n;
    cin >> n;
    cout << (sqrt(n)==trunc(sqrt(n))) << endl;
    return 0;
}